module.exports = {
  presets: ["@babel/preset-env"],
  plugins: [["@babel/transform-runtime"]],
};
