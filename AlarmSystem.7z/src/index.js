import "core-js/stable";
import "regenerator-runtime/runtime";
import "isomorphic-fetch";
import Vue from "vue";
import vuetify from "@src/plugins/vuetify";
import App from "@vue/App";

Vue.config.productionTip = false;

import VueRouter from "vue-router";
Vue.use(VueRouter);

import Vuex from "vuex";
Vue.use(Vuex);

import CoolLightBox from "vue-cool-lightbox";
import "vue-cool-lightbox/dist/vue-cool-lightbox.min.css";
Vue.use(CoolLightBox);
import {
  LMap,
  LTileLayer,
  LTooltip,
  LPopup,
  LMarker,
  LIcon,
  LCircle,
  LRectangle,
  LPolygon,
  LPolyline,
  LGeoJson,
} from "vue2-leaflet";
import "leaflet/dist/leaflet.css";
Vue.component("LMap", LMap);
Vue.component("LTileLayer", LTileLayer);
Vue.component("LTooltip", LTooltip);
Vue.component("LPopup", LPopup);
Vue.component("LMarker", LMarker);
Vue.component("LIcon", LIcon);
Vue.component("LCircle", LCircle);
Vue.component("LRectangle", LRectangle);
Vue.component("LPolygon", LPolygon);
Vue.component("LPolyline", LPolyline);
Vue.component("LGeoJson", LGeoJson);

import { Icon, tileLayer } from "leaflet";

import { marker } from "@src/res/markerUrl.js";

delete Icon.Default.prototype._getIconUrl;
Icon.Default.mergeOptions(marker);

const AppExtensionPlugin = {};
AppExtensionPlugin.install = function(Vue, options) {
  Vue.mixin({
    computed: {
      $app() {
        return this.$root.$children[0];
      },
      $app_imageViewer() {
        return this.$app.$refs.imageViewer;
      },
      $app_confirm() {
        return this.$app.$refs.confirm;
      },
      $app_overlay() {
        return this.$app.$refs.overlay;
      },
      $app_contextmenu() {
        return this.$app.$refs.contextmenu;
      },
    },
  });
};
Vue.use(AppExtensionPlugin);

const routes = [{ path: "/", component: () => import("@vue/pages/Main") }];
const router = new VueRouter({
  routes,
  linkActiveClass: "active",
});
const store = new Vuex.Store({
  state: {},
  mutations: {},
  actions: {},
});

router.beforeEach((to, from, next) => {
  next();
});
router.afterEach((to, from) => {
  window.scroll(0, 0);
});

const app = new Vue({
  el: "#app",
  router,
  store,
  vuetify,
  render: (h) => h(App),
});
