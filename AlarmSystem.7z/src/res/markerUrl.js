import marker_icon_2x from "@img/marker/marker-icon-2x.png";
import marker_icon from "@img/marker/marker-icon.png";
import marker_shadow from "@img/marker/marker-shadow.png";
export const marker = { iconRetinaUrl: marker_icon_2x, iconUrl: marker_icon, shadowUrl: marker_shadow };

import marker01_icon_2x from "@img/marker01/marker-icon-2x.png";
import marker01_icon from "@img/marker01/marker-icon.png";
import marker01_shadow from "@img/marker01/marker-shadow.png";
export const marker01 = { iconRetinaUrl: marker01_icon_2x, iconUrl: marker01_icon, shadowUrl: marker01_shadow };

import marker02_icon_2x from "@img/marker02/marker-icon-2x.png";
import marker02_icon from "@img/marker02/marker-icon.png";
import marker02_shadow from "@img/marker02/marker-shadow.png";
export const marker02 = { iconRetinaUrl: marker02_icon_2x, iconUrl: marker02_icon, shadowUrl: marker02_shadow };

import marker03_icon_2x from "@img/marker03/marker-icon-2x.png";
import marker03_icon from "@img/marker03/marker-icon.png";
import marker03_shadow from "@img/marker03/marker-shadow.png";
export const marker03 = { iconRetinaUrl: marker03_icon_2x, iconUrl: marker03_icon, shadowUrl: marker03_shadow };
