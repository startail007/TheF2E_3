<template>
  <v-app class="h-100">
    <router-view></router-view>
    <ImageViewer ref="imageViewer" class="imageViewer"></ImageViewer>
    <Contextmenu ref="contextmenu" class="contextmenu"></Contextmenu>
    <Confirm ref="confirm" class="confirm"></Confirm>
    <Overlay ref="overlay" class="overlay"></Overlay>
  </v-app>
</template>
<script>
import ImageViewer from "@vue/components/ImageViewer";
import Confirm from "@vue/components/Confirm";
import Overlay from "@vue/components/Overlay";
import mixins_funs from "@vue/mixins/funs";
import Contextmenu from "@vue/components/Contextmenu";
export default {
  name: "app",
  mixins: [mixins_funs],
  components: { ImageViewer, Confirm, Overlay, Contextmenu },
  data() {
    return {};
  },
  mounted() {},
  methods: {},
};
</script>
<style lang="scss">
@import "https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900";
@import "https://cdn.jsdelivr.net/npm/@mdi/font@4.x/css/materialdesignicons.min.css";
html {
  overflow: auto;
  height: 100%;
}
body {
  margin: 0;
  height: 100%;
}
.v-application--wrap {
  min-height: auto;
  height: 100%;
}
/*.theme--light.v-toolbar.v-sheet {
  background-color: transparent;
}
.theme--light.v-data-table {
  background-color: transparent;
}
.theme--light.v-card {
  background-color: transparent;
}
.v-dialog {
  .theme--light.v-card {
    background-color: white;
  }
}*/
.v-data-table {
  tr {
    th {
      white-space: nowrap;
    }
    td {
      &:not(:first-child) {
        min-width: 6em;
      }
    }
  }
}

/*.v-dialog.editDialog {
  height: 100%;
  overflow: hidden;
  .v-card {
    display: flex;
    flex-direction: column;
    height: 100%;

    .v-card__text {
      flex: 1;
      overflow: auto;
    }
  }
}*/

$breakpoints: "", "sm", "md", "lg", "xl";
$flexs: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, "auto", "none";
@each $breakpoint in $breakpoints {
  @if $breakpoint!= "" {
    @media (min-width: get-breakpoints($breakpoint)) {
      @for $i from 0 through 100 {
        .w-#{$breakpoint}-#{$i * 5} {
          width: #{$i * 5%};
        }
        .vw-#{$breakpoint}-#{$i * 5} {
          width: #{$i * 5vw};
        }
        .min-w-#{$breakpoint}-#{$i * 10} {
          min-width: #{$i * 10px};
        }
        .max-w-#{$breakpoint}-#{$i * 10} {
          max-width: #{$i * 10px};
        }
        .h-#{$breakpoint}-#{$i * 5} {
          height: #{$i * 5%};
        }
        .vh-#{$breakpoint}-#{$i * 5} {
          height: #{$i * 5vh};
        }
        .min-h-#{$breakpoint}-#{$i * 10} {
          min-height: #{$i * 10px};
        }
        .max-h-#{$breakpoint}-#{$i * 10} {
          max-height: #{$i * 10px};
        }
      }
      @each $flex in $flexs {
        .flex-#{$breakpoint}-#{$flex} {
          flex: #{$flex};
        }
      }
    }
  } @else {
    @for $i from 0 through 100 {
      .w-#{$i * 5} {
        width: #{$i * 5%};
      }
      .vw-#{$i * 5} {
        width: #{$i * 5vw};
      }
      .min-w-#{$i * 10} {
        min-width: #{$i * 10px};
      }
      .max-w-#{$i * 10} {
        max-width: #{$i * 10px};
      }
      .h-#{$i * 5} {
        height: #{$i * 5%};
      }
      .vh-#{$i * 5} {
        height: #{$i * 5vh};
      }
      .min-h-#{$i * 10} {
        min-height: #{$i * 10px};
      }
      .max-h-#{$i * 10} {
        max-height: #{$i * 10px};
      }
    }
    @each $flex in $flexs {
      .flex-#{$flex} {
        flex: #{$flex};
      }
    }
  }
}
</style>
<style lang="scss" scoped>
.imageViewer {
  z-index: 13000 !important;
}
.contextmenu {
  z-index: 13001 !important;
}
.confirm {
  z-index: 13002 !important;
}
.overlay {
  z-index: 13003 !important;
}
</style>
