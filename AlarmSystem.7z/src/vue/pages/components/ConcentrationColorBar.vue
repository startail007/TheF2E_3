<template>
  <div class="concentrationColorBar">
    <div class="colorBox" :style="{ backgroundImage: colorBox }"></div>
    <div class="texts">
      <div
        class="text"
        v-for="(text, index) in numbers"
        :key="index"
        :style="{ top: `${100 * (index / (numbers.length - 1))}%` }"
      >
        {{ text }}
      </div>
    </div>
  </div>
</template>
<script>
export default {
  components: {},
  props: {
    numbers: {
      type: Array,
    },
    colors: {
      type: Array,
    },
  },
  data() {
    return {
      colorBox: "",
    };
  },
  mounted() {
    this.colorBox = `linear-gradient(to bottom,${this.colors.join(",")})`;
  },
  methods: {},
  computed: {},
};
</script>
<style lang="scss" scoped>
.concentrationColorBar {
  position: absolute;
  left: 10px;
  top: 10px;
  width: 10px;
  height: 250px;
  z-index: 9999;
  .colorBox {
    position: absolute;
    width: 100%;
    height: 100%;
  }
  .texts {
    position: absolute;
    left: 100%;
    height: 100%;
    width: 0;
    .text {
      position: absolute;
      left: 11px;
      color: #fff;
      font-size: 12px;
      //transform: translateY(-100%);
      letter-spacing: 0.05em;
      min-width: 30px;
      text-align: center;
      text-shadow: 0px 0px 2px rgba(0, 0, 0, 0.25);
      &::before {
        content: "";
        position: absolute;
        display: block;
        width: 11px;
        height: 1px;
        background-color: #777;
        left: -11px;
        top: 0%;
      }
      &::after {
        content: "";
        position: absolute;
        display: block;
        width: 100%;
        height: 1px;
        left: 0px;
        top: 0%;
        background-color: #777;
      }
    }
  }
}
</style>
