<template>
  <div></div>
</template>
<script>
export default {
  components: {},
  data() {
    return {};
  },
  mounted() {},
  methods: {},
  computed: {},
};
</script>
<style lang="scss" scoped>
.pageItem {
  font-weight: bold;
  letter-spacing: 0.25em;
  &.active {
    background-color: transparent;
    color: turquoise;
  }
  &::before {
    content: none;
  }
  &.active::after {
    content: "";
    position: absolute;
    display: block;
    left: 0;
    bottom: 0;
    width: 100%;
    height: 2px;
    background-color: turquoise;
  }
}
</style>
