<template>
  <!-- <div></div> -->
  <div class="ProgressLinear">
    <div class="progressValue" :style="{ width: `${100 * progress}%` }"></div>
    <div class="dateItems" v-if="timeLine.length">
      <template v-if="changeBool">
        <div
          class="dateItem"
          v-for="(item, index) in timeLine"
          :key="index"
          :style="{ left: `${100 * (index / (timeLine.length - 1))}%` }"
        >
          <div class="date" v-if="index === 0 || item.date !== timeLine[index - 1].date">
            {{ item.date }}
          </div>
          <div
            class="time"
            @click="time_click(index)"
            :class="{ active: loadIndex > index, loading: loadIndex === index }"
          >
            {{ item.time }}
          </div>
        </div>
      </template>
      <template v-else>
        <div
          class="dateItem"
          v-for="(item, index) in timeLine"
          :key="index"
          :style="{ left: `${100 * (index / (timeLine.length - 1))}%` }"
        >
          <template v-if="index === 0 || index === timeLine.length - 1">
            <div class="date">
              {{ item.date }}
            </div>
            <div
              class="time"
              @click="time_click(index)"
              :class="{ active: loadIndex > index, loading: loadIndex === index }"
            >
              {{ item.time }}
            </div>
          </template>
        </div>
      </template>
    </div>
    <div
      class="end"
      v-if="loadIndex < timeLine.length"
      :style="{ left: `${100 * (Math.max(loadIndex - 1, 0) / (timeLine.length - 1))}%` }"
    ></div>

    <template v-if="changeBool">
      <div
        class="waiting d-flex align-center"
        v-if="loadIndex < timeLine.length"
        :style="{ left: `${100 * (loadIndex / (timeLine.length - 1))}%` }"
      >
        <div class="mr-2">等待載入</div>
        <v-progress-circular :width="1" :size="12" indeterminate color="#cccccc"></v-progress-circular>
      </div>
    </template>
    <template v-else>
      <div
        class="waiting d-flex align-center"
        v-if="loadIndex < timeLine.length"
        :style="{ left: `${100 * (loadIndex / (timeLine.length - 1))}%` }"
      >
        <div class="mr-2">等待載入</div>
        <v-progress-circular :width="2" :size="12" indeterminate color="#cccccc"></v-progress-circular>
      </div>
    </template>
  </div>
</template>
<script>
export default {
  components: {},
  props: {
    times: {
      type: Array,
    },
    /*progress: {
      type: Number,
    },*/
    loadIndex: {
      type: Number,
    },
  },
  data() {
    return {
      timeLine: [],
      progress: 0,
      playBool: false,
      segment: 0,
      maxIndex: 0,
    };
  },
  watch: {
    times(val) {
      this.timeLine = val.map((el) => {
        const s = el.toISOString();
        return {
          date: s.substr(0, 10),
          time: s.substr(11, 5),
        };
      });
      this.segment = val.length - 1;
    },
    loadIndex(val) {
      this.maxIndex = Math.max(val - 1, 0);
    },
  },
  mounted() {},
  methods: {
    update() {
      if (this.playBool) {
        this.updateProgress(this.progress + 0.001);
        requestAnimationFrame(this.update);
      }
    },
    playToggle() {
      this.playBool = !this.playBool;
      if (this.playBool) {
        if (this.progress >= this.maxProgress) {
          this.progress = 0;
        }
        this.update();
      }
    },
    time_click(index) {
      this.playBool = false;
      this.updateProgress(index / this.segment);
      this.$emit("jump", index);
    },
    updateProgress(progress, redraw = false) {
      const maxProgress = this.maxProgress;
      const oldPlayProgress = this.progress;
      const playProgress = Math.min(progress, maxProgress);
      this.progress = playProgress;
      if (playProgress >= maxProgress) {
        this.playBool = false;
      }
      const size = 5;
      const allFrame = this.segment * size;
      const oldPlayIndex = parseInt((allFrame * oldPlayProgress).toFixed(2));
      const playIndex = parseInt((allFrame * playProgress).toFixed(2));
      if (oldPlayIndex !== playIndex || redraw) {
        const timeRate = playIndex / size;
        this.$emit("rate", timeRate);
      }
    },
  },
  computed: {
    maxProgress() {
      return this.maxIndex / this.segment;
    },
    changeBool() {
      switch (this.$vuetify.breakpoint.name) {
        case "xs":
          return false;
        case "sm":
          return false;
        case "md":
          return true;
        case "lg":
          return true;
        case "xl":
          return true;
      }
    },
  },
};
</script>
<style lang="scss" scoped>
.ProgressLinear {
  position: relative;
  width: 100%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.5);
  .progressValue {
    position: absolute;
    height: 100%;
    background-color: rgb(255, 255, 255);
  }

  .dateItems {
    position: absolute;
    width: 100%;
    left: 0;
    top: 0;
    /*.date {
    position: absolute;
    transform: translateX(-50%);
    color: #fff;
    top: -35px;
    left: 0px;
    font-size: 12px;
  }*/
    .dateItem {
      position: absolute;
      color: #fff;
      top: -20px;
      font-size: 12px;
      .date {
        transform: translateX(-50%);
        position: absolute;
        white-space: nowrap;
        top: -15px;
        pointer-events: none;
        text-shadow: 0px 0px 2px rgba(0, 0, 0, 0.25);
      }
      .time {
        transform: translateX(-50%);
        position: absolute;
        white-space: nowrap;
        cursor: pointer;
        color: #777;
        text-shadow: 0px 0px 2px rgba(0, 0, 0, 0.25);
        &.active {
          color: #fff;
        }
        &.loading {
          color: rgb(202, 50, 50);
        }
      }
    }
  }

  .waiting {
    transform: translateX(-50%);
    position: absolute;
    white-space: nowrap;
    pointer-events: none;
    color: #fff;
    font-size: 12px;
    padding: 4px 8px;
    top: 10px;
    background-color: rgba(202, 50, 50, 0.75);
    border-radius: 5px;
    &::before {
      content: "";
      position: absolute;
      width: 0;
      height: 0;
      border-color: transparent transparent rgba(202, 50, 50, 0.75);
      border-style: solid;
      border-width: 0 5px 8px;
      left: 50%;
      transform: translateX(-50%);
      top: -8px;
    }
  }
  .end {
    transform: translateX(-50%);
    position: absolute;
    pointer-events: none;
    background-color: rgba(255, 255, 255, 0.25);
    height: 100%;
    width: 2px;
  }
}
</style>
