<template>
  <div>
    <v-app-bar class="bar" app elevate-on-scroll>
      <v-container class="pa-0 fill-height">
        <div class="mr-10 d-flex align-center">
          <v-avatar color="grey darken-1" size="32"> </v-avatar>
          <div class="ml-3">PM2.5擴散警報系統</div>
        </div>
        <!-- <slot name="items"></slot> -->
        <Menu class="d-none d-md-flex"></Menu>
        <v-spacer></v-spacer>
        <!-- <slot name="endItems"></slot> -->
        <!-- <v-app-bar-nav-icon
          class="d-flex d-md-none"
          @click="$refs.sidebar.isOpen = !$refs.sidebar.isOpen"
        ></v-app-bar-nav-icon> -->
      </v-container>
    </v-app-bar>
    <Sidebar ref="sidebar">
      <template v-slot:content>
        <div class="d-flex pa-4">
          <v-spacer></v-spacer>
          <v-icon @click="$refs.sidebar.isOpen = false">
            mdi-close
          </v-icon>
        </div>
        <Menu class="d-flex flex-column"></Menu>
      </template>
    </Sidebar>
  </div>
</template>
<script>
import Menu from "@vue/pages/components/Menu";
import Sidebar from "@vue/pages/components/Sidebar";
export default {
  components: { Menu, Sidebar },
  data() {
    return {};
  },
  mounted() {},
  methods: {},
  computed: {},
};
</script>
<style lang="scss" scoped>
.bar {
  // background-image: url(~@img/header_bg.jpg);
  // background-size: cover;
  // background-position: center;
}
.logo {
  max-height: 40px;
}
</style>
