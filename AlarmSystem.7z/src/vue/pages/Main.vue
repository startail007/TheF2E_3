<template>
  <v-sheet class="content h-100">
    <!-- <Header></Header> -->
    <v-main class="main h-100">
      <LMap ref="myMap" :zoom="zoom" :center="center" class="w-100 h-100" :options="options">
        <LTileLayer :url="url" :attribution="attribution" />
        <LGeoJson :geojson="geojson" :options="geoOptions" :optionsStyle="geoStyle" />
      </LMap>
      <div class="playBox">
        <div class="d-flex w-100 h-100">
          <div class="d-flex align-center justify-center">
            <v-btn x-small depressed color="white" height="100%" @click="playButton_click">
              <v-icon small v-if="$refs.progressLinear && $refs.progressLinear.playBool">mdi-pause</v-icon>
              <v-icon small v-else>mdi-play</v-icon>
            </v-btn>
          </div>
          <div class="h-100 px-8 w-100">
            <ProgressLinear
              ref="progressLinear"
              :times="times"
              :loadIndex="loadIndex"
              @rate="time_rate"
            ></ProgressLinear>
          </div>
        </div>
      </div>
      <ConcentrationColorBar :numbers="map_pm25" :colors="map_pm25Color"></ConcentrationColorBar>
    </v-main>
  </v-sheet>
</template>
<script>
import Header from "@vue/pages/components/Header";
import ProgressLinear from "@vue/pages/components/ProgressLinear";
import ConcentrationColorBar from "@vue/pages/components/ConcentrationColorBar";
import mixins_funs from "@vue/mixins/funs";
import { map_pm25, getPM25Color, map_pm25Color } from "@js/funs";
import { Float } from "@js/float";
import areaLine_city_kao from "@src/res/areaLine_city_kao";
import axios from "axios";
import * as PIXI from "pixi.js";
import "leaflet-pixi-overlay";
import L from "leaflet";
import BezierEasing from "bezier-easing";
import clustering from "density-clustering";
const isProduction = process.env.NODE_ENV === "production";
const apiUrl = isProduction ? "" : "http://localhost:7788/";
export default {
  mixins: [mixins_funs],
  components: { Header, ConcentrationColorBar, ProgressLinear },
  data() {
    return {
      zoom: 9,
      center: L.latLng(22.9, 120.65),
      //url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
      //attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors',
      // url:
      //   "https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png?api_key=fd166c00-c805-4c05-863f-cfd230f3a9fa",
      url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
      attribution: '&copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors',
      options: {
        minZoom: 9,
        maxZoom: 18,
        bounds: L.latLngBounds([
          [22.0, 119.55],
          [23.8, 121.75],
        ]),
        maxBounds: L.latLngBounds([
          [22.0, 119.55],
          [23.8, 121.75],
        ]),
        zoomControl: false,
        //attributionControl: false,
      },
      geojson: null,
      geoOptions: {},
      geoStyle: {
        weight: 3,
        // color: "#0000ff",
        // opacity: 1,
        fill: false,
      },
      siteList: {}, //測站資訊
      siteTimeline: [], //測站上PM2.5濃度時間軸
      times: [], //時間軸
      mapPopup: L.popup({ autoPan: false, pane: "popupPane" }),
      mapPopupInfo: null,
      markers: {},
      loadIndex: 0,
      segment: 12,
      map_pm25: map_pm25,
      map_pm25Color: map_pm25Color,
      map_text: {
        // stid: "測站編號",
        iit: "測站編號",
        latLng: "經緯度",
        "pm2.5": "PM2.5",
        date_time: "更新時間",
        county: "縣市",
        town: "鄉鎮市區",
      },
      params: {},
    };
  },
  mounted() {
    const getUrlString = location.href;
    const url = new URL(getUrlString);
    const params = {
      time:
        url.searchParams.get("time") ??
        (() => {
          const now = new Date();
          now.setUTCHours(now.getUTCHours() + 8);
          now.setMinutes(Math.floor(now.getMinutes() / 5) * 5 - 15);
          now.setSeconds(0, 0);
          return now.toISOString();
        })(),
      zoom: parseInt(url.searchParams.get("zoom") ?? 10),
      lat: parseFloat(url.searchParams.get("lat") ?? 22.9),
      lng: parseFloat(url.searchParams.get("lng") ?? 120.65),
      stid: url.searchParams.get("stid") ?? "",
    };
    this.params = params;
    this.geojson = areaLine_city_kao;
    this.map.setView(new L.LatLng(params.lat, params.lng), params.zoom);

    this.getAPI(apiUrl + "getSites").then((data) => {
      this.siteList = data;
      for (let i = 0; i < this.segment + 1; i++) {
        const date = new Date(params.time);
        date.setMinutes(date.getMinutes() + i * 5);
        date.setSeconds(0, 0);
        this.times.push(date);
      }
      this.mapInit();
      this.updateHistoricalData((date, count, maxCount, success, complete) => {
        //console.log(date, count, maxCount, success, complete);
        if (count === 0 && success) {
          this.$refs.progressLinear.updateProgress(0, true);

          if (params.stid) {
            this.updatePopup(params.stid);
            this.mapPopup.setLatLng(this.siteList[params.stid].latLng);
            if (!this.mapPopup.isOpen()) {
              this.map.openPopup(this.mapPopup);
            }
          }
        }
        if (!success) {
          let bool = false;
          const intervalID = setInterval(() => {
            const date = new Date();
            if (date.getMinutes() % 5 == 0 && date.getSeconds() == 0) {
              if (!bool) {
                bool = true;
                this.updateHistoricalData((date, count, maxCount, success, complete) => {
                  if (count === 0 && success) {
                    this.$refs.progressLinear.updateProgress(0, true);
                  }
                  if (complete) {
                    clearInterval(intervalID);
                  }
                });
              }
            } else {
              if (bool) {
                bool = false;
              }
            }
          }, 500);
        }
      });
    });
  },
  methods: {
    updateHistoricalData(fun) {
      this.getHistoricalDataLoop(
        this.times,
        this.loadIndex,
        this.times.length,
        (date, count, maxCount, success, data) => {
          if (success) {
            this.siteTimeline.push(data);
            this.loadIndex = count + 1;
          }
          fun && fun(date, count, maxCount, success, count + 1 >= maxCount);
        }
      );
    },
    time_rate(timeRate) {
      const dataRate = timeRate % 1;
      const dataIndex0 = Math.floor(timeRate);
      const dataIndex1 = Math.min(dataIndex0 + 1, this.loadIndex - 1);
      const data0 = this.siteTimeline[dataIndex0].data;
      const data1 = this.siteTimeline[dataIndex1].data;
      this.updateScenes(data0, data1, dataRate);
    },
    playButton_click() {
      this.$refs.progressLinear.playToggle();
    },
    getHistoricalDataLoop(times, count, maxCount, fun) {
      if (count < maxCount) {
        const date = times[count];
        const now = new Date();
        now.setUTCHours(now.getUTCHours() + 8);
        now.setMinutes(now.getMinutes() - 15);
        if (date > now) {
          fun && fun(date, count, maxCount, false);
          return;
        }
        this.getAPI(apiUrl + "getEvent", { time: date.toISOString() }).then((data) => {
          fun && fun(date, count, maxCount, true, data);
          this.getHistoricalDataLoop(times, count + 1, maxCount, fun);
        });
      }
    },
    getAPI(url, params) {
      return axios
        .get(url, { params })
        .then((response) => response.data)
        .catch((error) => {
          console.log(error);
        });
    },
    updatePopup(stid) {
      const info = this.siteList[stid];
      if (info) {
        this.mapPopupInfo = info;
        let s = "";
        for (let key in this.map_text) {
          s += `<tr><td class="pa-1">${this.map_text[key]}</td><td class="pa-1">${info[key] ?? ""}</td></tr>`;
        }
        s = `<table><tbody>${s}</tbody></table>`;
        this.mapPopup.setContent(s);
      }
    },
    updateScenes(data0, data1, dataRate) {
      // const mapList = [];
      // const loc = [];
      // for (let key in this.siteList) {
      //   mapList.push(key);
      //   loc.push(this.siteList[key].latLng);
      // }
      // const dbscan = new clustering.DBSCAN();
      // const clusters = dbscan.run(loc, 0.01, 2);
      // console.log(clusters, dbscan.noise);
      // for (let i = 0; i < clusters.length; i++) {
      //   for (let j = 0; j < clusters[i].length; j++) {
      //     const key = mapList[clusters[i][j]];
      //     this.drawIcon(this.markers[key].icon, 0xff0000, this.params.stid === key);
      //   }
      // }
      // console.log(mapList, loc);
      for (let key in this.siteList) {
        const el = this.siteList[key];
        let val = 0;
        if (data0[key] && data1[key]) {
          val = parseFloat(Float.mix(data0[key]["pm2.5"] ?? 0, data1[key]["pm2.5"] ?? 0, dataRate).toFixed(2));
          //console.log(dataRate);
          el["pm2.5"] = parseFloat((data0[key]["pm2.5"] ?? 0).toFixed(2));
          el["date_time"] = data0[key]["date_time"];
        } else if (data0[key]) {
          val = parseFloat((data0[key]["pm2.5"] ?? 0).toFixed(2));
          el["pm2.5"] = parseFloat((data0[key]["pm2.5"] ?? 0).toFixed(2));
          el["date_time"] = data0[key]["date_time"];
        } else if (data1[key]) {
          val = parseFloat((data1[key]["pm2.5"] ?? 0).toFixed(2));
          el["pm2.5"] = parseFloat((data1[key]["pm2.5"] ?? 0).toFixed(2));
          el["date_time"] = data1[key]["date_time"];
        }
        const color = parseInt(getPM25Color(val).replace("#", ""), 16);
        this.drawIcon(this.markers[key].icon, color, this.params.stid === key);
      }
      if (this.mapPopup.isOpen()) {
        this.updatePopup(this.mapPopupInfo?.["stid"]);
      }
    },
    drawIcon(icon, color, active = false) {
      icon.clear();
      icon.lineStyle(0);
      icon.beginFill(color, 0.25);
      icon.drawCircle(0, 0, 15);
      icon.endFill();
      icon.lineStyle(0);
      icon.beginFill(color, 1);
      icon.drawCircle(0, 0, 5);
      icon.endFill();
      if (active) {
        icon.lineStyle(3, 0xffffff, 1);
        icon.beginFill(0, 0);
        icon.drawCircle(0, 0, 22);
        icon.endFill();
      }
    },
    createMarker(key) {
      const marker = new PIXI.Container();
      const icon = new PIXI.Graphics();
      icon.interactive = true;
      icon.buttonMode = true;
      icon.infoKey = key;
      marker.addChild(icon);
      return { marker, icon };
    },
    mapInit() {
      const easing = BezierEasing(0, 0, 1, 0.5);
      const loader = new PIXI.Loader();
      loader.load((_loader, resources) => {
        const pixiContainer = new PIXI.Container();
        const markersContainer = new PIXI.Container();
        pixiContainer.addChild(markersContainer);

        for (let key in this.siteList) {
          this.markers[key] = { latLng: this.siteList[key].latLng, ...this.createMarker(key) };
          this.drawIcon(this.markers[key].icon, 0xffffff, this.params.stid === key);
          markersContainer.addChild(this.markers[key].marker);
        }

        let zoomChangeTs = null;
        const pixiOverlay = L.pixiOverlay(
          (utils, event) => {
            const container = utils.getContainer();
            const renderer = utils.getRenderer();
            const invScale = 1 / Math.max(utils.getScale(event.zoom), 1.25);

            if (event.type === "add") {
              const project = utils.latLngToLayerPoint;
              const interaction = new PIXI.InteractionManager(renderer);
              this.map.on("click", (e) => {
                const pointerEvent = e.originalEvent;
                const pixiPoint = new PIXI.Point();
                interaction.mapPositionToPoint(pixiPoint, pointerEvent.clientX, pointerEvent.clientY);
                const target = interaction.hitTest(pixiPoint, container);
                if (target) {
                  this.updatePopup(target.infoKey);
                  this.mapPopup.setLatLng(this.siteList[target.infoKey].latLng);
                  this.map.openPopup(this.mapPopup);
                }
              });
              for (let key in this.markers) {
                const el = this.markers[key];
                const marker = el.marker;
                const markerCoords = project(el.latLng);
                marker.x = markerCoords.x;
                marker.y = markerCoords.y;
                marker.scale.set(invScale);
              }
            } else if (event.type === "zoomanim") {
              zoomChangeTs = 0;
              for (let key in this.markers) {
                const marker = this.markers[key].marker;
                marker.currentScale = marker.scale.x;
                marker.targetScale = invScale;
              }
            } else if (event.type === "redraw") {
              const delta = event.delta;
              // markers.forEach((marker) => {
              //   marker.rotation -= 0.03 * delta;
              // });

              if (zoomChangeTs !== null) {
                const duration = 17;
                zoomChangeTs += delta;
                let lambda = zoomChangeTs / duration;
                if (lambda > 1) {
                  lambda = 1;
                  zoomChangeTs = null;
                }
                lambda = easing(lambda);
                for (let key in this.markers) {
                  const el = this.markers[key];
                  const marker = el.marker;
                  marker.scale.set(marker.currentScale + lambda * (marker.targetScale - marker.currentScale));
                }
              }
            }

            renderer.render(container);
          },
          pixiContainer,
          {
            destroyInteractionManager: true,
          }
        );
        pixiOverlay.addTo(this.map);
        const ticker = new PIXI.Ticker();
        ticker.add((delta) => {
          pixiOverlay.redraw({ type: "redraw", delta: delta });
        });
        ticker.start();
        this.map.on("zoomanim", pixiOverlay.redraw, pixiOverlay);
      });
    },
  },
  computed: {
    map() {
      return this.$refs.myMap.mapObject;
    },
  },
};
</script>
<style lang="scss" scoped>
@import "~@css/_variables.scss";
.content {
  //min-height: 100vh;
}
.playBox {
  position: absolute;
  height: 20px;
  //background-color: #f00;
  bottom: 20px;
  left: 10px;
  right: 10px;
  z-index: 9999;
}
.content::v-deep .leaflet-layer {
  filter: brightness(1) invert(1) contrast(0.7) hue-rotate(200deg) saturate(0.1);
}
@media (min-width: get-breakpoints("sm")) {
}
@media (min-width: get-breakpoints("md")) {
}
@media (min-width: get-breakpoints("lg")) {
}
@media (min-width: get-breakpoints("xl")) {
}
</style>
